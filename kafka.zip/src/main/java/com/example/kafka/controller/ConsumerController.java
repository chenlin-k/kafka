package com.example.kafka.controller;


import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@EnableAutoConfiguration
public class ConsumerController {


    @RequestMapping("/in")
    public String in() {
        System.out.println("111111111111111");
        return "11111";
    }
}
