package com.example.kafka.utils;


import com.example.kafka.model.SpliderError;
import com.example.kafka.model.SpliderTopic;
import org.apache.log4j.Logger;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Date;

/*
    jdbc连接类

    chenlink
 */


public class JDBCConnetct {

    private static final Logger logger = Logger.getLogger(JDBCConnetct.class);

    private String query_splider_topic="SELECT topic FROM splider_topic where id=1";

    private String insert_splider_error="insert into splider_error (datasource,topic,detail,url,errorresion,createtime) values(?,?,?,?,?,?)";


    public String querySpliderTopic(Connection conn) throws SQLException{
        PreparedStatement ps = null;
        ResultSet rs = null;
        String topic=null;
        try {
            ps = conn.prepareStatement(query_splider_topic);
            rs = ps.executeQuery();
            while(rs.next()){
                topic=rs.getString("topic");
            }
        }catch (SQLException e) {
            logger.error("查询主题数据异常！\n"+e);
            throw e;
        }finally{
            DBManager.close(rs,ps,null);
        }
        return topic;
    }
    public void saveSpliderError(Connection conn,SpliderError se) throws SQLException{
        PreparedStatement ps = null;
        try {
            ps = conn.prepareStatement(insert_splider_error);
            int index = 1;
            ps.setString(index++,se.getDatasource());
            ps.setString(index++,se.getTopic());
            ps.setString(index++,se.getDetail());
            ps.setString(index++,se.getUrl());
            ps.setString(index++,se.getErrorresion());
            SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//设置日期格式
            String date = df.format(new Date());
            ps.setString(index++, date);
            ps.execute();
        } catch (SQLException e) {
            logger.error("保存插入solr的异常信息失败！\n" + e);
            throw e;
        } finally {
            DBManager.close(null, ps, null);
        }
    }
}